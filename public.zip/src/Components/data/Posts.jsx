const posts = [
  {
    id: 1,
    title: 'my first blog ',
    content: 'Hello its my first blog',
    author: 'Davit',
    date: '2025-06-20',
  },
  {
    id: 2,
    title: 'React',
    content: 'React its cool',
    author: 'Davit',
    date: '2025-06-21',
  },
]

export default posts
