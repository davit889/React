import "./Home.css";
function Home() {
  return (
    <div className='Home'>
      <h1>Welcome to the Home Page</h1>
    </div>
  )
}

export default Home
