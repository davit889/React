# Git

0. git pull
1. git status
2. git add .
3. git commit -m "your message here..."
4. git push
